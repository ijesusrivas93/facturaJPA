function getFactura(){
    $.getJSON("http://localhost:8080/JPAProfundizacion/services/Factura/list", function(result){
    	console.log(result);
    	for(var row=0; row<result.length; row=row+1){
    		var fecha = result[row].fecha;
    		var hora = result[row].hora;
    		var valortotal = result[row].valor_Total;
    		var nombrecliente = result[row].nombreCliente;
    		var nombrecajero = result[row].nombreUsuario;    		
    		var fac='<div class="row"><label> Fecha : </label><label> '+fecha+'</label></div>';
    		fac = fac+ '<div class="row"><label> hora : </label><label> '+hora+'</label></div>';
    		fac = fac+ '<div class="row"><label> Nombre Cliente : </label><label> '+nombrecliente+'</label></div>';
    		fac = fac+ '<div class="row"><label> Cajero : </label><label> '+nombrecajero+'</label></div>';
    		fac = fac+ '<div class="row"><label> Valor Total : </label><label> '+valortotal+'</label></div>';
    		
    		$("#dacfactura").append(fac);
    		
    		
    	}
    });
}



function getDetalle(){
    $.getJSON("http://localhost:8080/JPAProfundizacion/services/Detalle/list", function(result){
    	console.log(result);
    	for(var row=0; row<result.length; row=row+1){
    		var id = result[row].idProducto;
    		var name = result[row].nombre;
    		var precio = result[row].precio;
    		var cantidad = result[row].cantidad;
    		var valorUni = precio*cantidad;
    		console.log(id +" "+name+" "+precio+" "+cantidad);
    		var fac='<div class="row"><label class="col"> '+id+' </label><label class="col"> '+name+'</label>';
    		fac = fac+ '<label class="col"> '+precio +' </label><label class="col"> '+cantidad+'</label><label class="col">'+valorUni+'</label></div>';    		
    		$("#detalle").append(fac);
    	}
    });
}
