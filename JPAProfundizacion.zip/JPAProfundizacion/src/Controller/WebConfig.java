package Controller;

import javax.ws.rs.ApplicationPath; 
import javax.ws.rs.core.Application; 

@ApplicationPath("/services") 
public class WebConfig extends Application  {

}
