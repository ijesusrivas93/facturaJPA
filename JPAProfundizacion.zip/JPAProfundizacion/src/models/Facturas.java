package models;

public class Facturas {
	
	
	String nombreCliente;
	String nombreUsuario;
	String valor_Total;
	String fecha;
	String hora;
	public String getNombreCliente() {
		return nombreCliente;
	}
	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public String getValor_Total() {
		return valor_Total;
	}
	public void setValor_Total(String valor_Total) {
		this.valor_Total = valor_Total;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	
	
	

}
